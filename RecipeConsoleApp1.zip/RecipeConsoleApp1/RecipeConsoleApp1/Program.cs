﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            while (true)
            {
                // displays drop down list of choices for the user to choose from:
                Console.WriteLine("Choose an option from the list below:");
                Console.WriteLine("1. Enter recipe details");
                Console.WriteLine("2. Display recipe");
                Console.WriteLine("3. Scale recipe");
                Console.WriteLine("4. Reset all quantities");
                Console.WriteLine("5. Clear all existing data");
                Console.WriteLine("6. Exit");

                //declares the choices from the drop down list and stores them in memory
                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    //a method that deals with incorrectly entered information
                    Console.WriteLine("Invalid input. Please enter a number.");
                    continue;
                }
                // switch statement  allows us to execute multiple operations for the different possibles values of a single variable
                switch (choice)
                {
                    case 1:
                        recipe.EnterDetails();
                        break;
                    case 2:
                        recipe.Display();
                        break;
                    case 3:
                        recipe.Scale();
                        break;
                    case 4:
                        recipe.ResetQuantities();
                        break;
                    case 5:
                        recipe.Clear();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please choose again.");
                        break;
                }
            }
        }
    }
    // "Recipe" class combines data variables and functions into a single unit.
    class Recipe
    {
        private List<Ingredient> ingredients;
        private List<string> steps;

        public Recipe()
        {
            // the ingredient array makes it easier to organize and operate on large amounts of data that the user will enter about the recipe.
            ingredients = new List<Ingredient>();
            steps = new List<string>();
        }
        // public void statement is to specify that the method doesn't return a value.
        public void EnterDetails()
        {
            Console.WriteLine("Please enter the number of ingredients:");
            int numIngredients = int.Parse(Console.ReadLine());

            ingredients.Clear();
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter the name of ingredient {i + 1}:");
                string name = Console.ReadLine();

                Console.WriteLine($"Enter the quantity of ingredient {i + 1}:");
                double quantity = double.Parse(Console.ReadLine());

                Console.WriteLine($"Enter the unit of measurement for ingredient {i + 1}:");
                string unit = Console.ReadLine();

                ingredients.Add(new Ingredient(name, quantity, unit));
            }

            Console.WriteLine("Enter the number of steps needed for your recipe:");
            int numSteps = int.Parse(Console.ReadLine());

            steps.Clear();
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                string step = Console.ReadLine();
                steps.Add(step);
            }

            Console.WriteLine("Your recipe details were entered successfully!");
        }

        public void Display()
        {
            Console.WriteLine("Recipe:");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("Steps:");
            foreach (var step in steps)
            {
                Console.WriteLine(step);
            }
        }

        public void Scale()
        {
            Console.WriteLine("Enter scale factor (0.5, 2, or 3):");
            double factor = double.Parse(Console.ReadLine());

            foreach (var ingredient in ingredients)
            {
                ingredient.Quantity *= factor;
            }

            Console.WriteLine("Your recipe has been scaled successfully!");
        }

        public void ResetQuantities()
        {
            // Reset quantities to original values
            Console.WriteLine("Quantities reset successfully!");
        }

        public void Clear()
        {
            ingredients.Clear();
            steps.Clear();
            Console.WriteLine("All data cleared successfully!");
        }
    }

    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }

        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
        }
    }
}
    
        